KRISH OS ULTRA-LIGHT v0.4 — DESKTOP FOUNDATION
================================================

This is the next source-development stage in the existing KRISH OS workflow.
It is NOT a finished ISO and has NOT been boot-tested on the user's PC.

WHAT THIS STAGE ADDS
--------------------
- A lightweight Openbox graphical desktop session.
- LightDM graphical login manager and KRISH OS session entry.
- Tint2 panel and PCManFM desktop.
- Basic Xorg input/video driver metapackages.
- NetworkManager, Wi-Fi supplicant, common firmware packages.
- ALSA utilities and PulseAudio volume control utility.
- KRISH OS identity in /etc/os-release and build info.

TARGET
------
- Debian 13 (Trixie), amd64.
- Intended for low-memory systems; 2 GB RAM is still restrictive.
- The existing Windows 7 installation must remain untouched.
- A 10 GB pagefile/virtual memory does not replace physical RAM.

BUILD WORKFLOW
--------------
1. Upload this archive to the same GitHub repository.
2. Use the matching build-iso.yml from this package at:
   .github/workflows/build-iso.yml
3. Run GitHub Actions -> Build KRISH OS ISO -> Run workflow.
4. Download the ISO artifact only after the workflow succeeds.
5. Test in a virtual machine or Live USB first. Do NOT install or format disks.

IMPORTANT
---------
- The workflow builds in GitHub's cloud runner; it does not build on the
  Windows 7 computer.
- This stage is source preparation. Successful compilation, boot, graphics,
  Wi-Fi, audio, and device compatibility still require actual testing.
- Firefox ESR is included but may be slow with 2 GB RAM.
- Example.invalid URLs are placeholders, not real support websites.
